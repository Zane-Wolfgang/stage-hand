READ THIS FIRST
===============
A downloaded file cannot become a Home Screen app on its own. iPadOS only allows
"Add to Home Screen" for a page that is on a web address, and the Files app cannot
run a web page from a downloaded folder. There is no way around this without
Apple's App Store. So the app needs to be put on a web address ONE time (free,
about eight taps, below). After that it has its own icon on the Home Screen and
works with no connection.

To open the download on the iPad: in the Files app, tap the ZIP once to unzip it.
You will get a folder with the six files in it. Those are the files to upload in step 1.

STAGEHAND FOR iPAD
==================
This folder is Stagehand packaged as an installable web app. Once it is on the
internet at a web address, you open that address in Safari on the iPad, tap
Share, then "Add to Home Screen". After that it opens full screen like any app
and keeps working with no connection (after the first time it loads).

Keep these six files together, with exactly these names:
  index.html   manifest.webmanifest   sw.js   icon-180.png   icon-192.png   icon-512.png

STEP 1: PUT THE FILES ON A WEB ADDRESS (free)
---------------------------------------------
Option A: GitHub Pages (can be done entirely on the iPad)
  1. In Safari go to github.com, sign in (or make a free account).
  2. Tap + then "New repository". Name it stagehand. Make it Public. Create it.
  3. Tap "uploading an existing file", choose all six files from this folder, tap Commit.
  4. Settings, then Pages. Under "Build and deployment" pick Branch: main, folder: / (root). Save.
  5. After a minute the page shows your address: https://YOURNAME.github.io/stagehand/
Option B: Netlify (drag and drop, from a computer)
  1. Go to app.netlify.com/drop and drop this folder onto the page.
  2. It gives you an address. Open it on the iPad.
I could not test these hosting steps myself, so if a screen looks different from the
description, the idea is the same: upload the six files and turn on hosting for them.

STEP 2: INSTALL IT
------------------
Open the address in Safari, tap the Share button, tap "Add to Home Screen", tap Add.

USING IT WITH FINGERS AND APPLE PENCIL
--------------------------------------
  One finger drag           Turns the camera (button "Finger: camera")
  Two fingers pinch / drag  Zoom and slide the camera, always
  Tap an object             Selects it. Tap again to pick a body part
  Two-finger tap            Undo
  Three-finger tap          Redo
  Apple Pencil              Uses the current tool and never moves the camera
  No Pencil?                Tap "Finger: camera" so it says "Finger: tool". One finger then uses
                            the tool and two fingers still move the camera.
  Buttons at the top of the picture replace the keyboard:
    "Add to selection"  (like holding Shift)
    "Pick folder"       (like holding Alt: your next tap picks the folder)
    "Whole object"      (like Esc: go back from a body part)
    "Hide panels"       (like Tab)


OPTIONAL: AN ATTACHMENTS FILE FOR A CHARACTER
---------------------------------------------
If you have a text file called attachments.txt made by the Studio command-bar script
(it prints BODYPART, ACCESSORY and ATTACHMENT lines), put it with the character's other
files. Stagehand then uses it to know exactly which body part each accessory is attached
to, instead of guessing. On an iPad, pick it together with the other files, or put it
inside the character's ZIP.

GETTING A CHARACTER IN
----------------------
  Tap Import and pick either ONE ZIP of the character's folder (.obj, .mtl and pictures),
  or all the files at once. An iPad cannot pick a whole folder, so a ZIP is easiest.

ADDING A VOICE TRACK
--------------------
In the Animate panel, tap Add audio and pick an MP3, WAV or M4A. It appears under the layers as a
waveform. Drag the waveform sideways to line it up, or type the frame it starts at. Play and
scrubbing play the sound. Video exports (MP4) include it.

GETTING YOUR WORK OUT
---------------------
  Save, and every Export, brings up a "Save..." sheet. Tap it to send the file to Photos,
  Files, or another app. Videos are MP4 so they play in Photos.
  Autosave keeps a copy inside the app. Safari can clear that storage if the app is not
  used for a long time, so save a project file to Files for anything you care about.

THINGS THAT DIFFER FROM A COMPUTER
----------------------------------
  - No "Project folder" (iPads do not let web apps write into a folder you choose).
  - Large characters use a lot of memory. If the iPad pauses the 3D view, close other apps.
  - Keyboard shortcuts only work with a keyboard attached.

UPDATING LATER
--------------
  Upload the new index.html. Then change the number in sw.js ("stagehand-v1" to "stagehand-v2")
  and upload that too, so the app knows to fetch the new version.
